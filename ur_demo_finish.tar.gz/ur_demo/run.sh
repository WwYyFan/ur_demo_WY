#!/bin/bash

export ROS_MASTER_URI=http://192.168.2.109:11311
export ROS_IP=192.168.2.44
source /home/user/ur_demo/devel/setup.bash
rosrun arm2 main

exec bash
