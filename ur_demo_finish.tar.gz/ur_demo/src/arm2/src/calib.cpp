#include <opencv/cv.hpp>  
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>

#include <opencv2/aruco.hpp>
#include <opencv2/aruco/dictionary.hpp>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>

using namespace std;
using namespace cv;
Size image_size;  /* 图像的尺寸 */
// Mat cameraMatrix;
// Mat distCoeffs;
// float cameraArr[9] = {1033.256409930833, 0, 656.9802273509281,
//                         0, 1027.86626465706, 471.5456134476234,
//                         0, 0, 1};
// float distCoeffsArr[5] = {-0.3586709037865581, 0.2074340723382269, 0.0009838728129509542, -0.002129795094395934, -0.08884148631918931};
// Mat cameraMatrix = Mat(3, 3, CV_32FC1, Scalar::all(0));  /* 摄像机内参数矩阵 */
// Mat distCoeffs=Mat(1, 5, CV_32FC1,Scalar::all(0));       /* 摄像机的5个畸变系数：k1,k2,p1,p2,k3 */
Mat cameraMatrix = (Mat_<float>(3,3) << 1251.358862670783, 0, 623.1484462819398,
 0, 1245.149308201073, 429.487208843336,
 0, 0, 1);
Mat distCoeffs = (Mat_<float>(1,5) << -0.4139693932859538, 0.2393181704620453, 0.002448494773662026, -0.0008339480524195827, -0.07464047113669427);

int main(int argc, char *argv[])
{
    // for(int i=0;i<3;i++)
    // {
    //     for(int j=0;j<3;j++)
    //     {
    //         cameraMatrix.at<float>(i,j) = cameraArr[i*3+j];
    //     }
    // }
    // for(int i=0;i<5;i++)
    // {
    //     distCoeffs.at<float>(0,i) = distCoeffsArr[i];
    // }
    // cout << "caca" <<cameraMatrix<<endl;
    // cout << "distCoeffs" <<distCoeffs<<endl;


    ifstream fin("/home/user/handeyeCalib/calibdata.txt"); /* 标定所用图像文件的路径 */
    //读取每一幅图像，从中提取出角点，然后对角点进行亚像素精确化    
    // cout<<"开始提取角点………………";
    int image_count=0;  /* 图像数量 */
    
    Size board_size = Size(9,7);    /* 标定板上每行、列的角点数 */
    vector<Point2f> image_points_buf;  /* 缓存每幅图像上检测到的角点 */
    vector<vector<Point2f>> image_points_seq; /* 保存检测到的所有角点 */
    string filename;
    int count= -1 ;//用于存储角点个数。
    while (getline(fin,filename))
    {
        image_count++;        
        // 用于观察检验输出
        // cout<<"image_count = "<<image_count<<endl;        
        /* 输出检验*/
        // cout<<"-->count = "<<count;        
        Mat imageInput=imread(filename);

        waitKey(0);
        if (image_count == 1)  //读入第一张图片时获取图像宽高信息
        {
            image_size.width = imageInput.cols;
            image_size.height =imageInput.rows;            
            // cout<<"image_size.width = "<<image_size.width<<endl;
            // cout<<"image_size.height = "<<image_size.height<<endl;
        }
                //畸變矯正
        Mat view, rview, map1, map2;
        initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
        getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, image_size, 1, image_size, 0),
        image_size, CV_16SC2, map1, map2);
        Mat image0;
        cout << "daaad"<<endl;
        remap(imageInput, imageInput, map1, map2, INTER_LINEAR);
        // imshow("dd",imageInput);
        // waitKey(0);
        /* 提取角点 */
        if (0 == findChessboardCorners(imageInput,board_size,image_points_buf))
        {            
            cout<<"can not find chessboard corners!\n"; //找不到角点
            exit(1);
        } 
        else 
        {
            Mat view_gray;
            cvtColor(imageInput,view_gray,CV_RGB2GRAY);
            /* 亚像素精确化 */
            find4QuadCornerSubpix(view_gray,image_points_buf,Size(11,11)); //对粗提取的角点进行精确化
            image_points_seq.push_back(image_points_buf);  //保存亚像素角点
            /* 在图像上显示角点位置 */
            drawChessboardCorners(view_gray,board_size,image_points_buf,true); //用于在图片中标记角点
            imshow("Camera Calibration",view_gray);//显示图片
            waitKey(0);//暂停0.5S        
        }
    }

     
    std::cout << image_points_buf.at(0) << std::endl;
    std::cout << image_points_buf.at(8) << std::endl;
    std::cout << image_points_buf.at(54) << std::endl;
    std::cout << image_points_buf.at(62) << std::endl;
    std::cout << image_points_buf.at(15) << std::endl;
    std::cout << image_points_buf.at(25) << std::endl;
    std::cout << image_points_buf.at(49) << std::endl;
   
    
    vector<Point2f> image_point;
    image_point.push_back(Point2f(340.420, 314.783));
    image_point.push_back(Point2f(800.533, 297.100));
    image_point.push_back(Point2f(360.214, 652.786));
    image_point.push_back(Point2f(810.539, 638.127));
    image_point.push_back(Point2f(686.766, 358.900));
    image_point.push_back(Point2f(746.488, 414.467));
    image_point.push_back(Point2f(581.500, 590.500));

    vector<Point2f> robot_point;
    robot_point.push_back(Point2f(-451.75, -90.64));
    robot_point.push_back(Point2f(-449.67, 109.70));
    robot_point.push_back(Point2f(-303.58, -91.34));
    robot_point.push_back(Point2f(-299.59, 107.99));
    robot_point.push_back(Point2f(-425.21, 59.32));
    robot_point.push_back(Point2f(-400.95, 84.57));
    robot_point.push_back(Point2f(-325.36, 7.75));
    // vector<Point2f> image_point;
    // image_point.push_back(Point2f(485.510, 349.520));
    // image_point.push_back(Point2f(829.500, 370.000));
    // image_point.push_back(Point2f(474.000, 603.000));
    // image_point.push_back(Point2f(811.921, 623.648));
    // image_point.push_back(Point2f(740.786, 407.786));
    // image_point.push_back(Point2f(781.000, 453.000));
    // image_point.push_back(Point2f(645.214, 571.786));

    // vector<Point2f> robot_point;
    // robot_point.push_back(Point2f(689.27, 108.75));
    // robot_point.push_back(Point2f(698.18, -89.93));
    // robot_point.push_back(Point2f(540.61, 102.48));
    // robot_point.push_back(Point2f(548.62, -97.75));
    // robot_point.push_back(Point2f(671.50,-40.29));
    // robot_point.push_back(Point2f(648.56, -66.48));
    // robot_point.push_back(Point2f(569.78, 3.94));

    return 0;
}