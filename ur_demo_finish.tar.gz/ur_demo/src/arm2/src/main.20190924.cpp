// #include <opencv/cv.h>
// #include <opencv/highgui.h>
#include <opencv/cv.hpp>  
#include "opencv2/opencv.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/features2d/features2d.hpp>

#include <opencv2/aruco.hpp>
#include <opencv2/aruco/dictionary.hpp>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include "arm2/requestArm2.h"
#include "std_msgs/String.h"
#include "arm2/mindCamera.h"
#include "arm2/ur5.h"
#include "arm2/gripper.h"
#include "arm2/modbusrtu.h"

#include "ros/ros.h"
#include <Eigen/Dense>
#include <Eigen/Core>
#include <opencv2/core/eigen.hpp>

#define PI 3.141592653
using namespace std;
using namespace cv;
using namespace Eigen;
using namespace cv::xfeatures2d;

Size image_size;  /* 图像的尺寸 */

RNG rng(12345);
Mat image(960,1280,CV_8UC1);
Mat image_blur(960,1280,CV_8UC1);
IplImage *cam0Frame;
int thresh = 120;
double angle;

joint_angle_type joint_angle;
TCP_POS_struct_def pose;
joint_angle_type resetAngle;

Mat cameraMatrix;
Mat distCoeffs;
Mat h;
MatrixXd h_m;
Mat h2;
MatrixXd h_m2;
MatrixXd h_mN;
Mat templete1;

int count_time = 0;

Mat right_image = imread("/home/user/ur_demo/model1.bmp", 0);

Mat cameraMatrix2 = (Mat_<float>(3,3) << 1877.375181220042, 0, 643.8604467974208,
                    0, 1867.537689349586, 437.2761455229951,
                    0, 0, 1);
float arr[5] = {-0.4617277659389767, 0.6983364109908734, -0.0009885291895765176, -0.004874155412565024, -1.406098027609715};


bool flag = false;

Point2f pcenter_in_car;
double z_ang_in_car;

Vec3f rotationMatrixToEulerAngles(Mat &R)
{

    float sy = sqrt(R.at<double>(0,0) * R.at<double>(0,0) +  R.at<double>(1,0) * R.at<double>(1,0) );

    bool singular = sy < 1e-6; // If

    float x, y, z;
    if (!singular)
    {
        x = atan2(R.at<double>(2,1) , R.at<double>(2,2));
        y = atan2(-R.at<double>(2,0), sy);
        z = atan2(R.at<double>(1,0), R.at<double>(0,0));
    }
    else
    {
        x = atan2(-R.at<double>(1,2), R.at<double>(1,1));
        y = atan2(-R.at<double>(2,0), sy);
        z = 0;
    }
    return Vec3f(x, y, z);
}

void calibration()
{
    ifstream fin("/home/user/ur_demo/calibdata.txt"); /* 标定所用图像文件的路径 */
    ofstream fout("/home/user/ur_demo/caliberation_result.txt");  /* 保存标定结果的文件 */    
    //读取每一幅图像，从中提取出角点，然后对角点进行亚像素精确化    
    // cout<<"开始提取角点………………";
    int image_count=0;  /* 图像数量 */
    
    Size board_size = Size(9,7);    /* 标定板上每行、列的角点数 */
    vector<Point2f> image_points_buf;  /* 缓存每幅图像上检测到的角点 */
    vector<vector<Point2f>> image_points_seq; /* 保存检测到的所有角点 */
    string filename;
    int count= -1 ;//用于存储角点个数。
    while (getline(fin,filename))
    {
        image_count++;        
        // 用于观察检验输出
        // cout<<"image_count = "<<image_count<<endl;        
        /* 输出检验*/
        // cout<<"-->count = "<<count;        
        Mat imageInput=imread(filename);
        if (image_count == 1)  //读入第一张图片时获取图像宽高信息
        {
            image_size.width = imageInput.cols;
            image_size.height =imageInput.rows;            
            // cout<<"image_size.width = "<<image_size.width<<endl;
            // cout<<"image_size.height = "<<image_size.height<<endl;
        }
 
        /* 提取角点 */
        if (0 == findChessboardCorners(imageInput,board_size,image_points_buf))
        {            
            // cout<<"can not find chessboard corners!\n"; //找不到角点
            exit(1);
        } 
        else 
        {
            Mat view_gray;
            cvtColor(imageInput,view_gray,CV_RGB2GRAY);
            /* 亚像素精确化 */
            find4QuadCornerSubpix(view_gray,image_points_buf,Size(11,11)); //对粗提取的角点进行精确化
            image_points_seq.push_back(image_points_buf);  //保存亚像素角点
            /* 在图像上显示角点位置 */
            drawChessboardCorners(view_gray,board_size,image_points_buf,true); //用于在图片中标记角点
            // imshow("Camera Calibration",view_gray);//显示图片
            // waitKey(5);//暂停0.5S        
        }
    }

    int total = image_points_seq.size();
    // cout<<"total = "<<total<<endl;
    int CornerNum=board_size.width*board_size.height;  //每张图片上总的角点数
    for (int ii=0 ; ii<total ;ii++)
    {
        if (0 == ii%CornerNum)// 24 是每幅图片的角点个数。此判断语句是为了输出 图片号，便于控制台观看 
        {    
            int i = -1;
            i = ii/CornerNum;
            int j=i+1;
            // cout<<"--> 第 "<<j <<"图片的数据 --> : "<<endl;
        }
        if (0 == ii%3)    // 此判断语句，格式化输出，便于控制台查看
        {
            cout<<endl;
        }
        else
        {
            cout.width(10);
        }
        //输出所有的角点
        // cout<<" -->"<<image_points_seq[ii][0].x;
        // cout<<" -->"<<image_points_seq[ii][0].y;
    }    
    // cout<<"角点提取完成！\n";
 
    //以下是摄像机标定
    // cout<<"开始标定………………";
    /*棋盘三维信息*/
    Size square_size = Size(25,25);  /* 实际测量得到的标定板上每个棋盘格的大小 */
    vector<vector<Point3f>> object_points; /* 保存标定板上角点的三维坐标 */
    /*内外参数*/
    cameraMatrix=Mat(3,3,CV_32FC1,Scalar::all(0)); /* 摄像机内参数矩阵 */
    vector<int> point_counts;  // 每幅图像中角点的数量
    distCoeffs=Mat(1,5,CV_32FC1,Scalar::all(0)); /* 摄像机的5个畸变系数：k1,k2,p1,p2,k3 */
    vector<Mat> tvecsMat;  /* 每幅图像的旋转向量 */
    vector<Mat> rvecsMat; /* 每幅图像的平移向量 */
    /* 初始化标定板上角点的三维坐标 */
    int i,j,t;
    for (t=0;t<image_count;t++) 
    {
        vector<Point3f> tempPointSet;
        for (i=0;i<board_size.height;i++) 
        {
            for (j=0;j<board_size.width;j++) 
            {
                Point3f realPoint;
                /* 假设标定板放在世界坐标系中z=0的平面上 */
                realPoint.x = i*square_size.width;
                realPoint.y = j*square_size.height;
                realPoint.z = 0;
                tempPointSet.push_back(realPoint);
            }
        }
        object_points.push_back(tempPointSet);
    }
    /* 初始化每幅图像中的角点数量，假定每幅图像中都可以看到完整的标定板 */
    for (i=0;i<image_count;i++)
    {
        point_counts.push_back(board_size.width*board_size.height);
    }    
    /* 开始标定 */
    calibrateCamera(object_points,image_points_seq,image_size,cameraMatrix,distCoeffs,rvecsMat,tvecsMat,0);
    // cout<<"标定完成！\n";
    //对标定结果进行评价
    // cout<<"开始评价标定结果………………\n";
    double total_err = 0.0; /* 所有图像的平均误差的总和 */
    double err = 0.0; /* 每幅图像的平均误差 */
    vector<Point2f> image_points2; /* 保存重新计算得到的投影点 */
    // cout<<"\t每幅图像的标定误差：\n";
    fout<<"每幅图像的标定误差：\n";
    for (i=0;i<image_count;i++)
    {
        vector<Point3f> tempPointSet=object_points[i];
        /* 通过得到的摄像机内外参数，对空间的三维点进行重新投影计算，得到新的投影点 */
        projectPoints(tempPointSet,rvecsMat[i],tvecsMat[i],cameraMatrix,distCoeffs,image_points2);
        /* 计算新的投影点和旧的投影点之间的误差*/
        vector<Point2f> tempImagePoint = image_points_seq[i];
        Mat tempImagePointMat = Mat(1,tempImagePoint.size(),CV_32FC2);
        Mat image_points2Mat = Mat(1,image_points2.size(), CV_32FC2);
        for (int j = 0 ; j < tempImagePoint.size(); j++)
        {
            image_points2Mat.at<Vec2f>(0,j) = Vec2f(image_points2[j].x, image_points2[j].y);
            tempImagePointMat.at<Vec2f>(0,j) = Vec2f(tempImagePoint[j].x, tempImagePoint[j].y);
        }
        err = norm(image_points2Mat, tempImagePointMat, NORM_L2);
        total_err += err/=  point_counts[i];   
        // std::cout<<"第"<<i+1<<"幅图像的平均误差："<<err<<"像素"<<endl;   
        fout<<"第"<<i+1<<"幅图像的平均误差："<<err<<"像素"<<endl;   
    }   
    // std::cout<<"总体平均误差："<<total_err/image_count<<"像素"<<endl;   
    fout<<"总体平均误差："<<total_err/image_count<<"像素"<<endl<<endl;   
    // std::cout<<"评价完成！"<<endl;  
    //保存定标结果      
    // std::cout<<"开始保存定标结果………………"<<endl;       
    Mat rotation_matrix = Mat(3,3,CV_32FC1, Scalar::all(0)); /* 保存每幅图像的旋转矩阵 */
    fout<<"相机内参数矩阵："<<endl;   
    fout<<cameraMatrix<<endl<<endl;   
    fout<<"畸变系数：\n";   
    fout<<distCoeffs<<endl<<endl<<endl;   
    for (int i=0; i<image_count; i++) 
    { 
        fout<<"第"<<i+1<<"幅图像的旋转向量："<<endl;   
        fout<<tvecsMat[i]<<endl;   
        /* 将旋转向量转换为相对应的旋转矩阵 */   
        Rodrigues(tvecsMat[i],rotation_matrix);   
        fout<<"第"<<i+1<<"幅图像的旋转矩阵："<<endl;   
        fout<<rotation_matrix<<endl;   
        fout<<"第"<<i+1<<"幅图像的平移向量："<<endl;   
        fout<<rvecsMat[i]<<endl<<endl;   
    }   
    // std::cout<<"完成保存"<<endl; 
    fout<<endl;
      
    // Mat view, rview, map1, map2;
    // initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
    //     getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, image_size, 1, image_size, 0),
    //     image_size, CV_16SC2, map1, map2);

    // Mat image0 = imread("/home/user/ur_demo/calibdata/0.bmp");
    // Mat image0_clone = image0.clone();
    // remap(image0, image0_clone, map1, map2, INTER_LINEAR);
    // imwrite("/home/user/test.bmp", image0_clone);

    // MatrixXd cameraMatrix_m;
    // MatrixXd distCoeffs_m;

    // cv2eigen(cameraMatrix,cameraMatrix_m);
    // cv2eigen(distCoeffs,distCoeffs_m);
    // FILE *fp;
    // if((fp= fopen("/home/user/ur_demo/calib.txt","wb+")) == NULL)
    // {
    //     ROS_INFO("write calibration data error");
    //     return;
    // }

    // if(fp)
    // {
    //     for(int i=0;i<3;i++)
    //     {
    //         for(int j=0;j<3;j++)
    //         {
    //             fwrite(&cameraMatrix_m(i,j),sizeof(double),1,fp);
    //         }
    //     }

    //     for(int i=0;i<5;i++)
    //     {
    //         fwrite(&distCoeffs_m(0,i),sizeof(double),1,fp);
    //     }
    // }
    // fclose(fp);

    // std::cout << cameraMatrix_m << std::endl;
    // std::cout << distCoeffs_m << std::endl;
    return ;
}

bool findObjPose(Mat modelImage,Mat targetImage,Point2f& pCenter,double& zAng)
{
    vector<float> distCoeffs(arr,arr+5);
    // readCameraParameters(cameraMatrix2, distCoeffs);
    //识别marker
    Ptr<aruco::Dictionary> dictionary = cv::aruco::getPredefinedDictionary(cv::aruco::DICT_5X5_250);
    Ptr<aruco::DetectorParameters> detectorParameter = cv::aruco::DetectorParameters::create();
    vector<int> ids,model_ids; 
    vector<vector<Point2f> > corners,model_corners; 
    vector<Point2f> corner,model_corner; 
    aruco::detectMarkers(targetImage, dictionary, corners, ids,detectorParameter);// if at least one marker detected 
    aruco::detectMarkers(modelImage, dictionary, model_corners, model_ids,detectorParameter);// if at least one marker detected 

    // DetectARMarker detectARMarker;
    Mat imageCopy,imgeMarker;
    targetImage.copyTo(imageCopy);
    targetImage.copyTo(imgeMarker);
    vector<Vec3d> rvecs, tvecs; 
    Vec3f el;
    cout << "cameraMatrix2"<< endl <<cameraMatrix2 << endl;

    flag = false;

    if (ids.size() > 0) 
    { 
        for(int j = 0; j < ids.size(); j++)
        {
            // cout << "distCoeffs"<< endl <<distCoeffs << endl;
            cv::aruco::estimatePoseSingleMarkers(corners, 0.05, cameraMatrix2, distCoeffs, rvecs, tvecs); // draw axis for each marker 
            if (model_ids[0] == ids[j])
            {

                cv::aruco::drawDetectedMarkers(imageCopy, corners, ids);
                cv::aruco::drawMarker(dictionary,ids[j], 20,imgeMarker, 1);

                    /********划网格**********/      
                cv::Point2f p00 = corners[j][0] ;
                cv::Point2f p05 = corners[j][1] ;
                cv::Point2f p55 = corners[j][2] ;
                cv::Point2f p50 = corners[j][3] ;    
                int MarkerSize = 7;

                cv::Point2f p0n = p00 + (p05 - p00)*3/(2*MarkerSize);
                cv::Point2f p1n = p05 - (p05 - p00)*3/(2*MarkerSize);
                cv::Point2f p2n = p55 - (p55 - p50)*3/(2*MarkerSize);
                cv::Point2f p3n = p50 + (p55 - p50)*3/(2*MarkerSize);

                p00 = p0n + (p3n - p0n)*3/(2*MarkerSize);
                p05 = p1n + (p2n - p1n)*3/(2*MarkerSize);
                p50 = p3n - (p3n - p0n)*3/(2*MarkerSize);
                p55 = p2n - (p2n - p1n)*3/(2*MarkerSize);

                std::vector<std::vector<cv::Point2f> > cordMat;
                std::vector<cv::Point2f>  cordMat2;
                MarkerSize = MarkerSize - 3;
                for(int m = 0; m < MarkerSize + 1; m++)
                {
                    std::vector<cv::Point2f> ccc ;
                    for(int n = 0; n < MarkerSize + 1; n++)
                    {
                        cv::Point2f p0n = p00 + (p05 - p00)*n/MarkerSize;
                        cv::Point2f p5n = p50 + (p55 - p50)*n/MarkerSize;
                        cv::Point2f pmn = p0n + (p5n - p0n)*m/MarkerSize;
                        // std::cout << "pmn:" << pmn << std::endl;
                        // cordMat[m].push_back(pmn);
                        ccc.push_back(pmn);
                        // std::cout << "pmn:" << pmn << std::endl;
                    }
                    cordMat.push_back(ccc);

                }

                for(int k = 0; k < MarkerSize +1; k++)
                {
                    cv::line(imageCopy ,cordMat[k][0] ,cordMat[k][MarkerSize],{0 ,255 ,255} ,1 ,cv::LineTypes::LINE_AA ,0) ;//划横线
                    cv::line(imageCopy ,cordMat[0][k] ,cordMat[MarkerSize][k],{255 ,255 ,0} ,1 ,cv::LineTypes::LINE_AA ,0) ;//划竖线
                }  
                //
                for (int i = 0; i < corners[j].size(); i++)
                {
                    corner.push_back(corners[j][i]);
                    model_corner.push_back(model_corners[0][i]);
                }
                cv::aruco::drawAxis(imageCopy, cameraMatrix2, distCoeffs, rvecs[j], tvecs[j], 0.1); 
                cout << "rvecs[i]" << rvecs[j] << endl;
                cout << "tvecs[i]" << tvecs[j] << endl;
                Mat rotation_matrix = Mat(3,3,CV_32FC1, Scalar::all(0));
                Rodrigues(rvecs[j],rotation_matrix);
                cout << "rotation_matrix" << rotation_matrix <<endl;
                el = rotationMatrixToEulerAngles(rotation_matrix);
                cout << "el" << el <<endl;
                zAng = el[2];
                pCenter = (corner[0] + corner[1] + corner[2] + corner[3])/4;
                cout << "afa :" << zAng * 180 / M_PI <<" 度" <<  endl;
                cout << "目标的中心点："<< pCenter <<endl;
                if( (zAng * 180 / M_PI) > 90)
                {
                    double rect_angle = (zAng * 180 / M_PI) - 180;
                    zAng =  rect_angle * M_PI / 180;
                }

                if( (zAng * 180 / M_PI) < -90)
                {
                    double rect_angle = (zAng * 180 / M_PI) + 180;
                    zAng =  rect_angle * M_PI / 180;
                }
                flag = true;
            }
            
        }        
    }
    return flag;
}

bool requestCallBack(arm2::requestArm2::Request  &req,
                     arm2::requestArm2::Response &res)
{
    if(req.arrive)
    {   
        if(count_time == 0)
        {
            h_mN = h_m;
            right_image = imread("/home/user/ur_demo/model1.bmp", 0);
            //move to mid pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = -0.05572;
                pose.y  = 0.47418;
                pose.z  = 0.34852;
                pose.Rx = 0.0076;
                pose.Ry = -0.0059;
                pose.Rz = -1.4755;
	        	setTcpPos(pose,3);
                sleep(3);
            }  

            //move to push_takephoto pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = 0.50409;
                pose.y  = -0.13072;
                pose.z  = 0.41900;
                pose.Rx = 0.0011;
                pose.Ry = -0.0148;
                pose.Rz = -3.2152;
	        	setTcpPos(pose,3);
                sleep(3);
            }        

        }
        else if(count_time == 1)
        {
            h_mN = h_m;
            right_image = imread("/home/user/ur_demo/model2.bmp", 0);
            //move to mid pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = -0.05572;
                pose.y  = 0.47418;
                pose.z  = 0.34852;
                pose.Rx = 0.0076;
                pose.Ry = -0.0059;
                pose.Rz = -1.4755;
	        	setTcpPos(pose,3);
                sleep(3);
            }  

            //move to push_takephoto pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = 0.50409;
                pose.y  = -0.13072;
                pose.z  = 0.41900;
                pose.Rx = 0.0011;
                pose.Ry = -0.0148;
                pose.Rz = -3.2152;
	        	setTcpPos(pose,3);
                sleep(3);
            }     
        }
        else if(count_time == 2)
        {
            
            //move to mid pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = -0.05572;
                pose.y  = 0.47418;
                pose.z  = 0.34852;
                pose.Rx = 0.0076;
                pose.Ry = -0.0059;
                pose.Rz = -1.4755;
	        	setTcpPos(pose,3);
                sleep(3);
            }  

            //move to push_takephoto pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = 0.50409;
                pose.y  = -0.13072;
                pose.z  = 0.41900;
                pose.Rx = 0.0011;
                pose.Ry = -0.0148;
                pose.Rz = -3.2152;
	        	setTcpPos(pose,3);
                sleep(3);
            }     

            sleep(2);
            //take photo
            memcpy(cam0Frame->imageData,frameBuf,1280*960);
            if (cam0Frame) 
            {
                    image = cvarrToMat(cam0Frame);
                    // imwrite("/home/user/test.bmp",image);
                    calibration();
                    Mat view, rview, map1, map2;
                    initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
                    getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, image_size, 1, image_size, 0),
                    image_size, CV_16SC2, map1, map2);

                    Mat image0 = image.clone();
                    remap(image, image, map1, map2, INTER_LINEAR);
                    imwrite("/home/user/test.bmp",image);
            }
            else
            {
                ROS_INFO("Can not get image!!");
                res.grasp = false;
            }

            Mat real_image = image.clone();    
            Mat marker_in_car = imread("/home/user/ur_demo/model3.bmp");
            flag = findObjPose(marker_in_car,real_image,pcenter_in_car,z_ang_in_car);
            if(flag)
            {
                     //move to mid pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.05572;
                    pose.y  = 0.47418;
                    pose.z  = 0.34852;
                    pose.Rx = 0.0076;
                    pose.Ry = -0.0059;
                    pose.Rz = -1.4755;
	            	setTcpPos(pose,3);
                    sleep(3);
                }    
            
                //move to takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.36053;
                    pose.y  = 0.036;
                    pose.z  = 0.41976;
                    pose.Rx = 0.0;
                    pose.Ry = 0.0;
                    pose.Rz = 0.0;
	            	setTcpPos(pose,3);
                    sleep(3);
                }   
            }

            ROS_INFO("pcenter_in_car:%f,%f,%f",pcenter_in_car.x,pcenter_in_car.y,z_ang_in_car);

            h_mN = h_m2;
            right_image = imread("/home/user/ur_demo/model1.bmp", 0);
        }
        else
        {
            //move to mid pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = -0.05572;
                pose.y  = 0.47418;
                pose.z  = 0.34852;
                pose.Rx = 0.0076;
                pose.Ry = -0.0059;
                pose.Rz = -1.4755;
	        	setTcpPos(pose,3);
                sleep(3);
            }  

            //move to push_takephoto pose
            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = 0.50409;
                pose.y  = -0.13072;
                pose.z  = 0.41900;
                pose.Rx = 0.0011;
                pose.Ry = -0.0148;
                pose.Rz = -3.2152;
	        	setTcpPos(pose,3);
                sleep(3);
            }     

            sleep(2);
            //take photo
            memcpy(cam0Frame->imageData,frameBuf,1280*960);
            if (cam0Frame) 
            {
                    image = cvarrToMat(cam0Frame);
                    // imwrite("/home/user/test.bmp",image);
                    calibration();
                    Mat view, rview, map1, map2;
                    initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
                    getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, image_size, 1, image_size, 0),
                    image_size, CV_16SC2, map1, map2);

                    Mat image0 = image.clone();
                    remap(image, image, map1, map2, INTER_LINEAR);
                    imwrite("/home/user/test.bmp",image);
            }
            else
            {
                ROS_INFO("Can not get image!!");
                res.grasp = false;
            }

            Mat real_image = image.clone();    
            Mat marker_in_car = imread("/home/user/ur_demo/model3.bmp");
            flag = findObjPose(marker_in_car,real_image,pcenter_in_car,z_ang_in_car);
            if(flag)
            {
                     //move to mid pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.05572;
                    pose.y  = 0.47418;
                    pose.z  = 0.34852;
                    pose.Rx = 0.0076;
                    pose.Ry = -0.0059;
                    pose.Rz = -1.4755;
	            	setTcpPos(pose,3);
                    sleep(3);
                }    
            
                //move to takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.36053;
                    pose.y  = 0.036;
                    pose.z  = 0.41976;
                    pose.Rx = 0.0;
                    pose.Ry = 0.0;
                    pose.Rz = 0.0;
	            	setTcpPos(pose,3);
                    sleep(3);
                }   
            }

            ROS_INFO("pcenter_in_car:%f,%f,%f",pcenter_in_car.x,pcenter_in_car.y,z_ang_in_car);

            h_mN = h_m2;
            right_image = imread("/home/user/ur_demo/model2.bmp", 0);
        }

        
        gripper_open(100,100);
        sleep(1);

        while(grapImg==0)
		{
			printf("waitting take photo\n");
		}

        grapImg = 1;

        memcpy(cam0Frame->imageData,frameBuf,1280*960);
        if (cam0Frame) 
        {
            image = cvarrToMat(cam0Frame);
            // imwrite("/home/user/test.bmp",image);
            calibration();
            Mat view, rview, map1, map2;
            initUndistortRectifyMap(cameraMatrix, distCoeffs, Mat(),
            getOptimalNewCameraMatrix(cameraMatrix, distCoeffs, image_size, 1, image_size, 0),
            image_size, CV_16SC2, map1, map2);
            
            Mat image0 = image.clone();
            remap(image, image, map1, map2, INTER_LINEAR);
            // imwrite("/home/user/test.bmp",image);
        }
        else
        {
            ROS_INFO("Can not get image!!");
            res.grasp = false;
        }

        Mat left_image = image.clone();
        Point2f pcenter;
        double z_ang;
        flag = findObjPose(right_image,left_image,pcenter,z_ang);
        if(flag)
        {
            double graspX=0,graspY=0;
            graspX = (pcenter.x*h_mN(0,0) + pcenter.y*h_mN(0,1)+h_mN(0,2))*0.001;
            graspY = (pcenter.x*h_mN(1,0) + pcenter.y*h_mN(1,1)+h_mN(1,2))*0.001;
            ROS_INFO("pose2:%f,%f",graspX,graspY);


            //set pose
            if(1== readRobt(pose,&joint_angle))
		    {
                ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
                double joint_angle5 = joint_angle.angle[5]+z_ang;
		        joint_angle.angle[5] = joint_angle5;
		        setTcpPos(joint_angle,2);
                sleep(3);
                ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
            }

            if(1== readRobt(pose,&joint_angle))
	        {
                pose.x  = graspX;
                pose.y  = graspY;
                ROS_INFO("pose3:%f,%f",pose.x,pose.y);

	        	setTcpPos(pose,3);
                sleep(3);
            }    

            if(count_time == 0 || count_time == 1)
            {
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = -0.04745;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }    
        
                gripper_close(100,200);

                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.14745;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }

                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.419;
                    pose.Rx = 0.0011;
                    pose.Ry = -0.0148;
                    pose.Rz = -3.2152;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(2);
                }    

                //move to mid pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.05572;
                    pose.y  = 0.47418;
                    pose.z  = 0.34852;
                    pose.Rx = 0.0076;
                    pose.Ry = -0.0059;
                    pose.Rz = -1.4755;
	            	setTcpPos(pose,3);
                    sleep(3);
                }    

                if(count_time == 0)
                {
                    //move to push pose
                    if(1== readRobt(pose,&joint_angle))
	                {
                        pose.x  = -0.40988;
                        pose.y  = 0.14975;
                        pose.z  = 0.41976;
                        pose.Rx = 0.0;
                        pose.Ry = 0.0;
                        pose.Rz = 0.0;
	                	setTcpPos(pose,3);
                        sleep(3);
                    }  

                    //move to push pose
                    if(1== readRobt(pose,&joint_angle))
	                {
                        pose.z  = 0.14099;
	                	setTcpPos(pose,3);
                        sleep(3);
                    }
                }
                else
                {
                    //move to push pose
                    if(1== readRobt(pose,&joint_angle))
	                {
                        pose.x  = -0.45418;
                        pose.y  = -0.04115;
                        pose.z  = 0.41976;
                        pose.Rx = 0.0;
                        pose.Ry = 0.0;
                        pose.Rz = 0.0;
	                	setTcpPos(pose,3);
                        sleep(3);
                    }  

                    //move to push pose
                    if(1== readRobt(pose,&joint_angle))
	                {
                        pose.z  = 0.14099;
	                	setTcpPos(pose,3);
                        sleep(3);
                    }
                } 
                
                sleep(1);
                gripper_open(100,200);

                //move to takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.36053;
                    pose.y  = 0.036;
                    pose.z  = 0.41976;
                    pose.Rx = 0.0;
                    pose.Ry = 0.0;
                    pose.Rz = 0.0;
	            	setTcpPos(pose,3);
                    sleep(3);
                }  

                count_time++;
            }
            else if(count_time == 2)
            {
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.11834;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }    
        
                gripper_close(100,200);

                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.41977;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }

                //move to mid pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.05572;
                    pose.y  = 0.47418;
                    pose.z  = 0.34852;
                    pose.Rx = 0.0076;
                    pose.Ry = -0.0059;
                    pose.Rz = -1.4755;
	            	setTcpPos(pose,3);
                    sleep(3);
                }    


                //move to push_takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = 0.50409;
                    pose.y  = -0.13072;
                    pose.z  = 0.41900;
                    pose.Rx = 0.0011;
                    pose.Ry = -0.0148;
                    pose.Rz = -3.2152;
	            	setTcpPos(pose,3);
                    sleep(3);
                }     

                //set pose
                if(1== readRobt(pose,&joint_angle))
		        {
                    ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
                    double joint_angle5 = joint_angle.angle[5]+z_ang_in_car;
		            joint_angle.angle[5] = joint_angle5;
		            setTcpPos(joint_angle,2);
                    sleep(3);
                    ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
                }

                //move to push
                if(1== readRobt(pose,&joint_angle))
	            {
                    graspX = (pcenter_in_car.x*h_m(0,0) + pcenter_in_car.y*h_m(0,1)+h_m(0,2))*0.001;
                    graspY = (pcenter_in_car.x*h_m(1,0) + pcenter_in_car.y*h_m(1,1)+h_m(1,2))*0.001;
                    pose.x  = graspX;
                    pose.y  = graspY;
	            	setTcpPos(pose,3);
                    sleep(3);
                } 
                
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = -0.05261;
	            	setTcpPos(pose,4);
                    sleep(4);
                } 
                
                sleep(1);
                gripper_open(100,200);
                
                //move to push_takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = 0.50409;
                    pose.y  = -0.13072;
                    pose.z  = 0.41900;
                    pose.Rx = 0.0011;
                    pose.Ry = -0.0148;
                    pose.Rz = -3.2152;
	            	setTcpPos(pose,3);
                    sleep(3);
                } 
                count_time++;
            }
            else if(count_time == 3)
            {
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.11834;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }    
        
                gripper_close(100,200);

                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = 0.41977;
                    ROS_INFO("pose3:%f",pose.z);

	            	setTcpPos(pose,2);
                    sleep(3);
                }

                //move to mid pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = -0.05572;
                    pose.y  = 0.47418;
                    pose.z  = 0.34852;
                    pose.Rx = 0.0076;
                    pose.Ry = -0.0059;
                    pose.Rz = -1.4755;
	            	setTcpPos(pose,3);
                    sleep(3);
                }    


                //move to push_takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = 0.50409;
                    pose.y  = -0.13072;
                    pose.z  = 0.41900;
                    pose.Rx = 0.0011;
                    pose.Ry = -0.0148;
                    pose.Rz = -3.2152;
	            	setTcpPos(pose,3);
                    sleep(3);
                }     

                //set pose
                if(1== readRobt(pose,&joint_angle))
		        {
                    ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
                    double joint_angle5 = joint_angle.angle[5]+z_ang_in_car;
		            joint_angle.angle[5] = joint_angle5;
		            setTcpPos(joint_angle,2);
                    sleep(3);
                    ROS_INFO("joint_angle:%f",joint_angle.angle[5]);
                }

                //move to push
                if(1== readRobt(pose,&joint_angle))
	            {
                    graspX = (pcenter_in_car.x*h_m(0,0) + pcenter_in_car.y*h_m(0,1)+h_m(0,2))*0.001;
                    graspY = (pcenter_in_car.x*h_m(1,0) + pcenter_in_car.y*h_m(1,1)+h_m(1,2))*0.001;
                    pose.x  = graspX;
                    pose.y  = graspY;
	            	setTcpPos(pose,3);
                    sleep(3);
                } 
                
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.z  = -0.05261;
	            	setTcpPos(pose,4);
                    sleep(4);
                } 
                
                sleep(1);
                gripper_open(100,200);
                
                //move to push_takephoto pose
                if(1== readRobt(pose,&joint_angle))
	            {
                    pose.x  = 0.50409;
                    pose.y  = -0.13072;
                    pose.z  = 0.41900;
                    pose.Rx = 0.0011;
                    pose.Ry = -0.0148;
                    pose.Rz = -3.2152;
	            	setTcpPos(pose,3);
                    sleep(3);
                } 
                count_time = 0;
            }

            res.grasp = true;
        }    
        else
        {
            ROS_INFO("can't no found target !!!!");
            res.grasp = false;
        }

    }
    else
    {
        res.grasp = false;
    }

    return true;
}



int main(int argc, char **argv)
{		
    // ROS节点初始化
    ros::init(argc, argv, "arm2");
    // 创建节点句柄
    ros::NodeHandle n;
    
    vector<Point2f> image_point;
    image_point.push_back(Point2f(356.5, 276.5));
    image_point.push_back(Point2f(898.786, 317.786));
    image_point.push_back(Point2f(331.5, 676.5));
    image_point.push_back(Point2f(864.794, 718.536));
    image_point.push_back(Point2f(758.5, 374.5));
    image_point.push_back(Point2f(821, 447.5));
    image_point.push_back(Point2f(601.731, 634.269));
    
    vector<Point2f> robot_point;
    robot_point.push_back(Point2f(612.38, -24.92));
    robot_point.push_back(Point2f(579.67, -223.04));
    robot_point.push_back(Point2f(462.81, -0.52));
    robot_point.push_back(Point2f(432.32, -194.82));
    robot_point.push_back(Point2f(563.26, -168.75));
    robot_point.push_back(Point2f(534.25, -189.94));
    robot_point.push_back(Point2f(471.88, -103.54));

    h = findHomography(image_point, robot_point);
    cv2eigen(h,h_m);
    

    vector<Point2f> image_point2;
    image_point2.push_back(Point2f(245.195, 233.392));
    image_point2.push_back(Point2f(1006.5, 234.5));
    image_point2.push_back(Point2f(256, 787.5));
    image_point2.push_back(Point2f(995.448, 793.309));
    image_point2.push_back(Point2f(817.786, 327.214));
    image_point2.push_back(Point2f(913, 424));
    image_point2.push_back(Point2f(623.5, 706.5));
    

    vector<Point2f> robot_point2;
    robot_point2.push_back(Point2f(-455.51, -78.04));
    robot_point2.push_back(Point2f(-449.51, 123.45));
    robot_point2.push_back(Point2f(-305.58, -79.77));
    robot_point2.push_back(Point2f(-300.67, 120.45));
    robot_point2.push_back(Point2f(-426.03, 73.39));
    robot_point2.push_back(Point2f(-400.15, 98.41));
    robot_point2.push_back(Point2f(-327.41, 21.12));
    
    
    h2= findHomography(image_point2, robot_point2);
    cv2eigen(h2,h_m2);
   
    
    gripper_activate();
    gripper_open(100,100);
    // gripper_close(100,100);
    
    camera_init();

    cam0Frame = cvCreateImage(CvSize{1280,960},IPL_DEPTH_8U,1);

    // 创建一个名为request_another_arm2的server，注册回调函数requestCallBack()
    ros::ServiceServer service = n.advertiseService("request_arm2", requestCallBack);
    
    ROS_INFO("Arm2 Waitting.....");
    ros::spin();

	return 0;
	
}

