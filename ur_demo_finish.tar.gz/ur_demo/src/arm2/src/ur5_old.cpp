/*
 * ur5.cpp
 *
 *  Created on: May 6, 2018
 *      Author: user
 */

#include <modbus/modbus.h>
#include "arm2/ur5.h"
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <math.h>
#include <string.h>
void read_joint_data(Joint_struct_def &joint,unsigned char *buf)
{
	unsigned char *p=(unsigned char *)(&joint);

	for(int j=0;j<3;j++)
	{
		for(int i=0;i<8;i++)
		{
			p[i+j*8]=buf[7-i+j*8];
		}
	}

	for(int j=0;j<4;j++)
	{
		for(int i=0;i<4;i++)
		{
			p[i+24+j*4]=buf[4-i+j*4+24];
		}
	}
	p[47]=buf[47];
}



void read_tcp_data(TCP_POS_struct_def &tcp,unsigned char *buf)
{
	unsigned char *p=(unsigned char *)(&tcp);

	for(int j=0;j<6;j++)
	{
		for(int i=0;i<8;i++)
		{
			p[j*8+i]=buf[7-i+j*8];
		}
	}
}


void read_target_angle(double *angle,unsigned char *buf)
{
	unsigned char *p=(unsigned char *)(angle);
	buf=buf+12;
	for(int j=0;j<6;j++)
	{
		for(int i=0;i<8;i++)
		{
			p[j*8+i]=buf[7-i+j*8];
		}
	}
}

int equ(double *din1,double *din2,int size)
{
	double diff=0;
	for(int i=0;i<size;i++)
	{
		diff+=fabs((din1[i]-din2[i]));

	}
	if(diff>0.00001)
	{
		return -1;
	}
	else
	{
		return 0;
	}

}

void read_actual_angle(double *angle,unsigned char *buf)
{
	unsigned char *p=(unsigned char *)(angle);
	buf=buf+252;
	for(int j=0;j<6;j++)
	{
		for(int i=0;i<8;i++)
		{
			p[j*8+i]=buf[7-i+j*8];
		}
	}
}

int is_ok(void)
{
	int i=0;
		double angle_tar[6]={1};
		double angle_act[6]={0};
		unsigned char buf2[4096];
		int socketfd;
		struct sockaddr_in address;
		//create socket
		socketfd=socket(AF_INET,SOCK_STREAM,0);
		if(socketfd==-1)
		{
			perror("create :");
			return -1;
		}
		//port,30002
		address.sin_port=htons(TARGET_PORT2);
		//ip address
		address.sin_addr.s_addr=inet_addr(TARGET_IP);
		//address family
		address.sin_family=AF_INET;

		if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
		{
			perror("connect rec");
			return -1;
		}


		do
		{
		    read(socketfd,buf2,1060);
			read_target_angle(angle_tar,buf2);
			read_actual_angle(angle_act,buf2);

			i++;
		}
		while((0!=equ(angle_tar,angle_act,6)) and (i<20000));
		close(socketfd);
		return 0;
}

int setTcpPosl(TCP_POS_struct_def &pose,float t)
{

	char cmd[512]={0};
	TCP_POS_struct_def poseTarget;
	int socketfd;
	struct sockaddr_in address;
	//create socket
	socketfd=socket(AF_INET,SOCK_STREAM,0);
	if(socketfd==-1)
	{
		perror("create :");
		return -1;
	}
	//port,30002
	address.sin_port=htons(TARGET_PORT);
	//ip address
	address.sin_addr.s_addr=inet_addr(TARGET_IP);
	//address family
	address.sin_family=AF_INET;

	if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
	{
		perror("connect rec");
		return -1;
	}


	sprintf(cmd,"movel(p[%f,%f,%f,%f,%f,%f],a=1.5,v=3,t=%f)\n",pose.x,pose.y,pose.z,pose.Rx,pose.Ry,pose.Rz,t);
	int tlen=send(socketfd,cmd,strlen(cmd),0);

	 close(socketfd);


	 if(tlen==strlen(cmd))
	 {
		/// is_ok();
	  return 1;
	 }
	 else
	 {
		 return -1;
	 }
}

int setDigitOut(int i,int b)
{
	char cmd[512]={0};

		int socketfd;
		struct sockaddr_in address;
		//create socket
		socketfd=socket(AF_INET,SOCK_STREAM,0);
		if(socketfd==-1)
		{
			perror("create :");
			return -1;
		}
		//port,30002
		address.sin_port=htons(TARGET_PORT);
		//ip address
		address.sin_addr.s_addr=inet_addr(TARGET_IP);
		//address family
		address.sin_family=AF_INET;

		if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
		{
			perror("connect rec");
			return -1;
		}

		if(b==1)
		{
		sprintf(cmd,"set_digital_out(%d,True)\n",i);
		}
		else
		{
			sprintf(cmd,"set_digital_out(%d,False)\n",i);
		}
		int tlen=send(socketfd,cmd,strlen(cmd),0);

		 close(socketfd);

		 if(tlen==strlen(cmd))
		 {
			// is_ok();
		  return 1;
		 }
		 else
		 {
			 return -1;
		 }

}

int setTcpPos(joint_angle_type &pose,float t)
{
	char cmd[512]={0};

	int socketfd;
	struct sockaddr_in address;
	//create socket
	socketfd=socket(AF_INET,SOCK_STREAM,0);
	if(socketfd==-1)
	{
		perror("create :");
		return -1;
	}
	//port,30002
	address.sin_port=htons(TARGET_PORT);
	//ip address
	address.sin_addr.s_addr=inet_addr(TARGET_IP);
	//address family
	address.sin_family=AF_INET;

	if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
	{
		perror("connect rec");
		return -1;
	}


	sprintf(cmd,"movej([%f,%f,%f,%f,%f,%f],a=1.5,v=3,t=%f)\n",pose.angle[0],pose.angle[1],pose.angle[2],pose.angle[3],pose.angle[4],pose.angle[5],t);
	int tlen=send(socketfd,cmd,strlen(cmd),0);

	 close(socketfd);

	 if(tlen==strlen(cmd))
	 {
	//	 is_ok();
	  return 1;
	 }
	 else
	 {
		 return -1;
	 }

}

int setTcpPos(TCP_POS_struct_def &pose,float t)
{
	char cmd[512]={0};

	int socketfd;
	struct sockaddr_in address;
	//create socket
	socketfd=socket(AF_INET,SOCK_STREAM,0);
	if(socketfd==-1)
	{
		perror("create :");
		return -1;
	}
	//port,30002
	address.sin_port=htons(TARGET_PORT);
	//ip address
	address.sin_addr.s_addr=inet_addr(TARGET_IP);
	//address family
	address.sin_family=AF_INET;

	if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
	{
		perror("connect rec");
		return -1;
	}


	sprintf(cmd,"movej(p[%f,%f,%f,%f,%f,%f],a=1.5,v=3,t=%f)\n",pose.x,pose.y,pose.z,pose.Rx,pose.Ry,pose.Rz,t);
	int tlen=send(socketfd,cmd,strlen(cmd),0);

	 close(socketfd);

	 if(tlen==strlen(cmd))
	 {
	//	 is_ok();
	  return 1;
	 }
	 else
	 {
		 return -1;
	 }

}

//read tcp position
int readRobt(TCP_POS_struct_def &tcp,joint_angle_type *joint_angle)
{
	unsigned char buf2[4096];
	int socketfd;
	struct sockaddr_in address;
	//create socket
	socketfd=socket(AF_INET,SOCK_STREAM,0);
	if(socketfd==-1)
	{
		perror("create :");
		return -1;
	}
	//port,30002
	address.sin_port=htons(TARGET_PORT2);
	//ip address
	address.sin_addr.s_addr=inet_addr(TARGET_IP);
	//address family
	address.sin_family=AF_INET;

	if(-1==(connect(socketfd, (sockaddr *)(&address),sizeof(address))))
	{
		perror("connect rec");
		return -1;
	}

	int rlen=0;
	rlen=read(socketfd,buf2,1060);
	close(socketfd);
//	printf("read %d\n",rlen);
	if(rlen<1060)
	{
		printf("read %d\n",rlen);
		return -1;
	}

	int msgLen;
	int index=0;

	msgLen=(buf2[index]<<24) + (buf2[index+1]<<16) + (buf2[index+2]<<8)+(buf2[index+3]);
//	printf("msgLen is %d\n",msgLen);
	if(msgLen==0)
	{
		printf("msg zero\n");
		return -1;
	}

	index=5;

    read_tcp_data(tcp,buf2+444);

    unsigned char *p=buf2+252;
    unsigned char *p2=(unsigned char *)(joint_angle);

		for(int j=0;j<6;j++)
		{
			for(int i=0;i<8;i++)
			{
				p2[j*8+i]=p[7-i+j*8];
			}
		}


	 return 1;

}