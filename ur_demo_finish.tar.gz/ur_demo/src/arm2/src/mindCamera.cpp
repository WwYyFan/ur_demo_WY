/*
 * mindCamera.cpp
 *
 *  Created on: Mar 7, 2018
 *      Author: user
 */

#include "arm2/mindCamera.h"
#include <unistd.h>
#include <string.h>

CameraHandle hCamera;
unsigned char *frameBuf;

int grapImg=0;


void camCallBack(CameraHandle hCamera, BYTE *pFrameBuffer, tSdkFrameHead* pFrameHead,PVOID pContext)
{
	int i;


	i= CameraImageProcess(hCamera, pFrameBuffer, frameBuf,pFrameHead);
	  if(0== i)
	  {
		 // printf("process ok\n");
	  }
	  else
	  {
		  printf("process fialed %d \n",i);
	  }
	  grapImg=1;
	CameraReleaseImageBuffer(hCamera,pFrameBuffer);

}

int camera_init(void)
{
	if(CAMERA_STATUS_SUCCESS==CameraSdkInit(0))
	{
		printf("sdk init ok\n");
	}
	else
	{
		printf("error");
		return -1;
	}
	tSdkCameraDevInfo tCameraEnumList;
	tSdkCameraDevInfo temp[2];
	int iCameraCounts=2;

	 //枚举设备，并建立设备列表
	 CameraEnumerateDevice(temp,&iCameraCounts);
	// CameraEnumerateDevice(&tCameraEnumList,&iCameraCounts);

		//没有连接设备
		if(iCameraCounts==0){
			return -1;
		}

	 printf("counts:%d\n",iCameraCounts);
	 for(int i=0;i<iCameraCounts;++i)
     {
         printf("num =%d %s  %s  %s \n",i,temp[i].acProductName,temp[i].acFriendlyName,temp[i].acSn);
	 	 if(!strcmp(temp[i].acSn,"MVG0FF90F177E"))
	 	 {
	 	 	memcpy(&tCameraEnumList,&temp[i],sizeof(temp[i])); 
	 	 }
     }

		//相机初始化。初始化成功后，才能调用任何其他相机相关的操作接口
	 int   iStatus = CameraInit(&tCameraEnumList,0,0,&hCamera);

		//初始化失败
		if(iStatus!=CAMERA_STATUS_SUCCESS){
			printf("init camera failled\n");
			return -1;
		}
		else
		{
			printf("camera init ok\n");
		}
		tSdkCameraCapbility tCapability;
		//获得相机的特性描述结构体。该结构体中包含了相机可设置的各种参数的范围信息。决定了相关函数的参数
		CameraGetCapability(hCamera,&tCapability);
		printf("resolution is %d x% d\n",tCapability.sResolutionRange.iHeightMax,tCapability.sResolutionRange.iWidthMax);
		tSdkImageResolution imgRes={0};
		CameraGetImageResolution(hCamera,&imgRes);

		CameraSetImageResolution(hCamera,&imgRes);

		CameraSetCallbackFunction(hCamera,camCallBack, 0, 0);

		CameraSetIspOutFormat(hCamera,CAMERA_MEDIA_TYPE_MONO8);
		CameraSetAeState(hCamera,false);
		CameraSetExposureTime(hCamera,23000);


		frameBuf=(unsigned char*)malloc(tCapability.sResolutionRange.iHeightMax*tCapability.sResolutionRange.iWidthMax*3);


		/*让SDK进入工作模式，开始接收来自相机发送的图像
		数据。如果当前相机是触发模式，则需要接收到
		触发帧以后才会更新图像。    */
		if(0== CameraPlay(hCamera))
		{
		   printf("camera start success\n");
		}
		else
		{
		   printf("camera start fialed\n");
		}



		if(0==  CameraSetTriggerMode(hCamera,0))
		{
		  printf("set trigger mode sucesse\n");
		}
		else
		{
		  printf("set trigger mode fialed\n");
		}

		return 0;
}

void camera_close(void)
{
	CameraUnInit(hCamera);
	free(frameBuf);
}

