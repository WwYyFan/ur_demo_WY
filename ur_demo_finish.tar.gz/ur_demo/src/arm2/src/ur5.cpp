#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <math.h>
#include "fstream"
#include "assert.h"
#include "arm2/ur5.h"
#include <cstdlib>
#include <iostream>
#include <string>

#define ROBOT_IP "192.168.2.6"
#define MYPORT  30003
#define QUEUE   20
#define BUFFER_SIZE 2048

using namespace std;

void convertUnCharToStr(char* str, unsigned char* UnChar, int ucLen)
{
    int i = 0;
    for (i = 0; i < ucLen; i++)
    {
        //格式化输str,每unsigned char 转换字符占两位置%x写输%X写输
        sprintf(str + i * 2, "%02x", UnChar[i]);
    }
}

void convertStrToUnChar(char* str, unsigned char* UnChar)
{
    int i = strlen(str), j = 0, counter = 0;
    char c[2];
    unsigned int bytes[2];
    for (j = 0; j < i; j += 2)
    {
        if (0 == j % 2)
        {
            c[0] = str[j];
            c[1] = str[j + 1];
            sscanf(c, "%02x" , &bytes[0]);
            UnChar[counter] = bytes[0];
            counter++;
        }
    }
    return;
}

std::string Hex2String(char *pszHex, int nLen)
{
    if (NULL == pszHex || 0 == nLen)
    {
        return "";
    }
 
    std::string strRet = "";
    for (int i = 0; i < nLen; i++)
    {
        char szTmp[4] = {0};
        sprintf(szTmp, "%02x", (unsigned char)pszHex[i]);
        strRet += szTmp;
    }
 
    return strRet;
} 

unsigned int getbitu(const unsigned char *buff, int pos, int len)
{
    unsigned int bits=0;
    int i;
    for (i=pos;i<pos+len;i++)
    {
        bits=(bits<<1)+((buff[i/8]>>(7-i%8))&1u);   //从高位到低位逐位计算
    }
    return bits;
}


double HexToDouble(const unsigned char* buf)  //默认buf进行了高低地址转换
{
    double value = 0;
    unsigned int i = 0;
    unsigned int num,temp;
    int num2;
    bool flags1 = true;
 
    num = getbitu(buf,i,1); //标志位               
    i += 1;
//double型规定偏移量为1023，其表示范围为-1024-1023
    num2 = getbitu(buf,i,11) - 1023;        
    i += 11;    
 
    while(1)
    {
        if(flags1)
        {
            flags1 = false;
            value += 1 * pow(2,num2); num2--;
        }
        temp = getbitu(buf,i,1);    i += 1;
        value += temp * pow(2,num2); num2--;
        if(i == 64)
            break;
    }
    if(num == 1)
        value *= -1;
 
    return value;
}

int initRobot()
{
    ///定义sockfd
    int sock_cli = socket(AF_INET,SOCK_STREAM, 0);

    ///定义sockaddr_in
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(MYPORT);  ///服务器端口
    servaddr.sin_addr.s_addr = inet_addr(ROBOT_IP);  ///服务器ip

    //连接服务器，成功返回0，错误返回-1
    if (connect(sock_cli, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("connect");
        exit(1);
    }
    return sock_cli;
}

//read tcp position
int readRobt(TCP_POS_struct_def &tcp,joint_angle_type *joint_angle)
{
    int sock_cli = initRobot();
    char sendbuf[BUFFER_SIZE];
    char recvbuf[BUFFER_SIZE];
    double toler_dist = 0.001;
    double toler_angle = 0.017;

    std::cout << "send " << std::endl;
    std::string command;
    sprintf(sendbuf,"get_actual_tcp_pose() \n)");
    // strcpy(sendbuf,command.c_str());
    send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
    if(strcmp(sendbuf,"exit\n")==0)
    {
        perror("error");
        return -1;
    }
    
    sleep(0.001);
    recv(sock_cli, recvbuf, 4,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 8,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
   
    unsigned char buf[8];
    //joint_1
    recv(sock_cli, buf, 8,0); ///接收
    double joint_1 = HexToDouble(buf);
    std::cout << "joint_1:" << joint_1 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_2
    recv(sock_cli, buf, 8,0); ///接收
    double joint_2 = HexToDouble(buf);
    std::cout << "joint_2:" << joint_2 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_3
    recv(sock_cli, buf, 8,0); ///接收
    double joint_3 = HexToDouble(buf);
    std::cout << "joint_3:" << joint_3 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_4
    recv(sock_cli, buf, 8,0); ///接收
    double joint_4 = HexToDouble(buf);
    std::cout << "joint_4:" << joint_4 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_5
    recv(sock_cli, buf, 8,0); ///接收
    double joint_5 = HexToDouble(buf);
    std::cout << "joint_5:" << joint_5 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_6
    recv(sock_cli, buf, 8,0); ///接收
    double joint_6 = HexToDouble(buf);
    std::cout << "joint_6:" << joint_6 << std::endl;
    memset(buf, 0, sizeof(buf));

    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));

    //x
    recv(sock_cli, buf, 8,0); ///接收
    double mx = HexToDouble(buf);
    std::cout << "x:" << mx << std::endl;
    memset(buf, 0, sizeof(buf));
    //y
    recv(sock_cli, buf, 8,0);
    double my = HexToDouble(buf);
    std::cout << "y:" << my << std::endl;
    memset(buf, 0, sizeof(buf));
    //z
    recv(sock_cli, buf, 8,0);
    double mz = HexToDouble(buf);
    std::cout << "z:" << mz << std::endl;
    memset(buf, 0, sizeof(buf));
    //rx
    recv(sock_cli, buf, 8,0);
    double mrx = HexToDouble(buf);
    std::cout << "rx:" << mrx << std::endl;
    memset(buf, 0, sizeof(buf));
    //ry
    recv(sock_cli, buf, 8,0);
    double mry = HexToDouble(buf);
    std::cout << "ry:" << mry << std::endl;
    memset(buf, 0, sizeof(buf));
    //rz
    recv(sock_cli, buf, 8,0);
    double mrz = HexToDouble(buf);
    std::cout << "rz:" << mrz << std::endl;
    memset(buf, 0, sizeof(buf));
    close(sock_cli);
       
    tcp.x = mx;
    tcp.y = my;
    tcp.z = mz;
    tcp.Rx = mrx;
    tcp.Ry = mry;
    tcp.Rz = mrz;

    joint_angle->angle[0] = joint_1;
    joint_angle->angle[1] = joint_2;
    joint_angle->angle[2] = joint_3;
    joint_angle->angle[3] = joint_4;
    joint_angle->angle[4] = joint_5;
    joint_angle->angle[5] = joint_6;

    return 1;

}

int setTcpPos(TCP_POS_struct_def &pose,double t)
{
    return move(pose.x,pose.y,pose.z,pose.Rx,pose.Ry,pose.Rz,1.5,3.0,t);
}

int setTcpMuiltPos(TCP_POS_struct_def &pose1,TCP_POS_struct_def &pose2,double t)
{
    return moveMulitPose(pose1.x,pose1.y,pose1.z,pose1.Rx,pose1.Ry,pose1.Rz,pose2.x,pose2.y,pose2.z,pose2.Rx,pose2.Ry,pose2.Rz,1.5,3.0,t);
    
}


int setTcpPos(joint_angle_type &pose,double t)
{
    return moveAngle(pose.angle[0],pose.angle[1],pose.angle[2],pose.angle[3],pose.angle[4],pose.angle[5],t);
}

int moveMulitPose(double x1,double y1,double z1,double rx1,double ry1,double rz1,
                double x2,double y2,double z2,double rx2,double ry2,double rz2,double a,double v,double t)
{
    int sock_cli = initRobot();
    char sendbuf[BUFFER_SIZE];
    char recvbuf[BUFFER_SIZE];
    double toler_dist = 0.001;
    double toler_angle = 0.017;

    std::cout << "send " << std::endl;
   
    std::string command = "def process():\n";
    sprintf(sendbuf," movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf)\n",x1,y1,z1,rx1,ry1,rz1,a,v,t);
    command += sendbuf;
    memset(sendbuf, 0, sizeof(sendbuf));
    sprintf(sendbuf," movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf)\n",x2,y2,z2,rx2,ry2,rz2,a,v,t);
    command += sendbuf;
    memset(sendbuf, 0, sizeof(sendbuf));
    command += "end\n";
    memset(sendbuf, 0, sizeof(sendbuf));
    strcpy(sendbuf, command.c_str());
    std::cout << command << std::endl;
    
    // sprintf(sendbuf,"def moveMulitPose(): \n movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf) \n movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf) \n end \n",x1,y1,z1,rx1,ry1,rz1,a,v,t,x2,y2,z2,rx2,ry2,rz2,a,v,t);

    // strcpy(sendbuf,command.c_str());
    send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
    if(strcmp(sendbuf,"exit\n")==0)
    {
        perror("error");
        return -1;
    }
    
    
    sleep(0.001);
    recv(sock_cli, recvbuf, 4,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 8,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    
    //x
    unsigned char buf[8];
    recv(sock_cli, buf, 8,0); ///接收
    double mx = HexToDouble(buf);
    // std::cout << "x:" << mx << std::endl;
    memset(buf, 0, sizeof(buf));
    //y
    recv(sock_cli, buf, 8,0);
    double my = HexToDouble(buf);
    // std::cout << "y:" << my << std::endl;
    memset(buf, 0, sizeof(buf));
    //z
    recv(sock_cli, buf, 8,0);
    double mz = HexToDouble(buf);
    // std::cout << "z:" << mz << std::endl;
    memset(buf, 0, sizeof(buf));
    //rx
    recv(sock_cli, buf, 8,0);
    double mrx = HexToDouble(buf);
    // std::cout << "rx:" << mrx << std::endl;
    memset(buf, 0, sizeof(buf));
    //ry
    recv(sock_cli, buf, 8,0);
    double mry = HexToDouble(buf);
    // std::cout << "ry:" << mry << std::endl;
    memset(buf, 0, sizeof(buf));
    //rz
    recv(sock_cli, buf, 8,0);
    double mrz = HexToDouble(buf);
    // std::cout << "rz:" << mrz << std::endl;
    memset(buf, 0, sizeof(buf));
    // close(sock_cli);
    
    recv(sock_cli, buf, 1556,0);
    memset(buf, 0, sizeof(buf));

    
    while( (fabs(mx - x2) > toler_dist || fabs(my - y2) > toler_dist || fabs(mz -z2) > toler_dist))
    {
        // sock_cli = initRobot();
        recv(sock_cli, recvbuf, 4,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 8,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));

        //x
        unsigned char buf[8];
        recv(sock_cli, buf, 8,0); ///接收
        mx = HexToDouble(buf);
        // std::cout << "x:" << mx << std::endl;
        memset(buf, 0, sizeof(buf));
        //y
        recv(sock_cli, buf, 8,0);
        my = HexToDouble(buf);
        // std::cout << "y:" << my << std::endl;
        memset(buf, 0, sizeof(buf));
        //z
        recv(sock_cli, buf, 8,0);
        mz = HexToDouble(buf);
        // std::cout << "z:" << mz << std::endl;
        memset(buf, 0, sizeof(buf));
        //rx
        recv(sock_cli, buf, 8,0);
        mrx = HexToDouble(buf);
        // std::cout << "rx:" << mrx << std::endl;
        memset(buf, 0, sizeof(buf));
        //ry
        recv(sock_cli, buf, 8,0);
        mry = HexToDouble(buf);
        // std::cout << "ry:" << mry << std::endl;
        memset(buf, 0, sizeof(buf));
        //rz
        recv(sock_cli, buf, 8,0);
        mrz = HexToDouble(buf);
        // std::cout << "rz:" << mrz << std::endl;
        memset(buf, 0, sizeof(buf));

        sleep(0.001);
        

    }
    close(sock_cli);
    
    memset(sendbuf, 0, sizeof(sendbuf));
    memset(recvbuf, 0, sizeof(recvbuf));

    return 1;
}

int setTcpMulitPos(TCP_POS_struct_def &pose,double t)
{
    return moveMulitPose(pose.x,pose.y,pose.z,pose.Rx,pose.Ry,pose.Rz,pose.x,pose.y,pose.z+0.1,pose.Rx,pose.Ry,pose.Rz,1.5,3,t);
}

// int move(double x,double y,double z,double rx,double ry,double rz,double a,double v,double t)
// {
// 	int sock_cli = initRobot();
//     std::cout << "a" << std::endl;
//     char sendbuf[BUFFER_SIZE];
//     char recvbuf[BUFFER_SIZE];
//     double toler_dist = 0.002;
//     double toler_angle = 0.01;

//     std::cout << "send2" << std::endl;
//     std::string command;
//     sprintf(sendbuf,"movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf) \n)",x,y,z,rx,ry,rz,a,v,t);
//     // strcpy(sendbuf,command.c_str());
//     send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
//     if(strcmp(sendbuf,"exit\n")==0)
//     {
//         perror("error");
//         return -1;
//     }
    
//     sleep(0.001);
//     memset(recvbuf, 0, sizeof(recvbuf));
//     recv(sock_cli, recvbuf, 2048,0); ///接收

//     double mx,my,mz,mrx,mry,mrz;
//     char buf[8];
//     unsigned char un_buf[8];

//     int index = 445;

//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     mx = HexToDouble(un_buf);
//     std::cout << "mx:" << mx << std::endl;
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my = HexToDouble(un_buf);
//     std::cout << "my:" << my << std::endl;
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     mz = HexToDouble(un_buf);
//     std::cout << "mz:" << mz << std::endl;
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     mrx = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     mry = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     mrz = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     while(fabs(mx - x) > toler_dist && fabs(my - y) > toler_dist && fabs(mz -z) > toler_dist)
//     {
//         memset(recvbuf, 0, sizeof(recvbuf));
//         recv(sock_cli, recvbuf, 2048,0); ///接收

//         index = 444;

//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         mx = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         mz = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         mrx = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         mry = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         mrz = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//     }       

//     close(sock_cli);
//     return 1;
// }


// int moveAngle(double jonit_1,double jonit_2,double jonit_3,double jonit_4,double jonit_5,double jonit_6,double t)
// {
//     int sock_cli = initRobot();
//     char sendbuf[BUFFER_SIZE];
//     char recvbuf[BUFFER_SIZE];
//     double toler_dist = 0.002;
//     double toler_angle = 0.02;

//     std::cout << "send2" << std::endl;
//     std::string command;
//     sprintf(sendbuf,"movej([%f,%f,%f,%f,%f,%f],a=1.5,v=3,t=%f)\n",jonit_1,jonit_2,jonit_3,jonit_4,jonit_5,jonit_6,t);
//     // strcpy(sendbuf,command.c_str());
//     send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
//     if(strcmp(sendbuf,"exit\n")==0)
//     {
//         perror("erroclose()r");
//         return -1;
//     }
    
    
//     memset(recvbuf, 0, sizeof(recvbuf));
//     recv(sock_cli, recvbuf, 2048,0); ///接收

//     double my_joint_1,my_joint_2,my_joint_3,my_joint_4,my_joint_5,my_joint_6;
//     char buf[8];
//     unsigned char un_buf[8];

//     int index = 252;

//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_1 = HexToDouble(un_buf);
//     std::cout << "my_joint_1:" << my_joint_1 << std::endl;
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_2 = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_3 = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_4 = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_5 = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));

//     index += 8;
//     strcpy(&recvbuf[index],buf);
//     convertStrToUnChar(buf,un_buf);
//     my_joint_6 = HexToDouble(un_buf);
//     memset(buf, 0, sizeof(buf));
//     memset(buf, 0, sizeof(un_buf));
//     close(sock_cli);

//     while(fabs(my_joint_1 - jonit_1) > toler_angle && fabs(my_joint_2 - jonit_2) > toler_angle && fabs(my_joint_3 - jonit_3) > toler_angle
//        &&  fabs(my_joint_4 - jonit_4) > toler_angle && fabs(my_joint_5 - jonit_5) > toler_angle && fabs(my_joint_6 - jonit_6) > toler_angle)
//     {

//         sock_cli = initRobot();
//         memset(recvbuf, 0, sizeof(recvbuf));
//         recv(sock_cli, recvbuf, 2048,0); ///接收

//         index = 252;

//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_1 = HexToDouble(un_buf);
//         std::cout << "my_joint_1:" << my_joint_1 << std::endl;
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_2 = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_3 = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_4 = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_5 = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         index += 8;
//         strcpy(&recvbuf[index],buf);
//         convertStrToUnChar(buf,un_buf);
//         my_joint_6 = HexToDouble(un_buf);
//         memset(buf, 0, sizeof(buf));
//         memset(buf, 0, sizeof(un_buf));

//         close(sock_cli);
//     }
//     return 1;
// }


int move(double x,double y,double z,double rx,double ry,double rz,double a,double v,double t)
{
	int sock_cli = initRobot();
    char sendbuf[BUFFER_SIZE];
    char recvbuf[BUFFER_SIZE];
    double toler_dist = 0.001;
    double toler_angle = 0.017;

    std::cout << "send " << std::endl;
    std::string command;
    sprintf(sendbuf,"movel(p[%lf, %lf,%lf, %lf, %lf, %lf],a=%lf,v=%lf,t=%lf) \n)",x,y,z,rx,ry,rz,a,v,t);
    // strcpy(sendbuf,command.c_str());
    send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
    if(strcmp(sendbuf,"exit\n")==0)
    {
        perror("error");
        return -1;
    }
    
    sleep(0.1);

    recv(sock_cli, recvbuf, 4,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 8,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    
    //x
    unsigned char buf[8];
    recv(sock_cli, buf, 8,0); ///接收
    double mx = HexToDouble(buf);
    // std::cout << "x:" << mx << std::endl;
    memset(buf, 0, sizeof(buf));
    //y
    recv(sock_cli, buf, 8,0);
    double my = HexToDouble(buf);
    // std::cout << "y:" << my << std::endl;
    memset(buf, 0, sizeof(buf));
    //z
    recv(sock_cli, buf, 8,0);
    double mz = HexToDouble(buf);
    // std::cout << "z:" << mz << std::endl;
    memset(buf, 0, sizeof(buf));
    //rx
    recv(sock_cli, buf, 8,0);
    double mrx = HexToDouble(buf);
    // std::cout << "rx:" << mrx << std::endl;
    memset(buf, 0, sizeof(buf));
    //ry
    recv(sock_cli, buf, 8,0);
    double mry = HexToDouble(buf);
    // std::cout << "ry:" << mry << std::endl;
    memset(buf, 0, sizeof(buf));
    //rz
    recv(sock_cli, buf, 8,0);
    double mrz = HexToDouble(buf);
    // std::cout << "rz:" << mrz << std::endl;
    memset(buf, 0, sizeof(buf));

    recv(sock_cli, buf, 1556,0);
    memset(buf, 0, sizeof(buf));
    
    // close(sock_cli);
       
    
    while( fabs(mx - x) > toler_dist || fabs(my - y) > toler_dist || fabs(mz -z) > toler_dist)
    {
        // sock_cli = initRobot();

        recv(sock_cli, recvbuf, 4,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 8,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));

        //x
        unsigned char buf[8];
        recv(sock_cli, buf, 8,0); ///接收
        mx = HexToDouble(buf);
        // std::cout << "x:" << mx << std::endl;
        memset(buf, 0, sizeof(buf));
        //y
        recv(sock_cli, buf, 8,0);
        my = HexToDouble(buf);
        // std::cout << "y:" << my << std::endl;
        memset(buf, 0, sizeof(buf));
        //z
        recv(sock_cli, buf, 8,0);
        mz = HexToDouble(buf);
        // std::cout << "z:" << mz << std::endl;
        memset(buf, 0, sizeof(buf));
        //rx
        recv(sock_cli, buf, 8,0);
        mrx = HexToDouble(buf);
        // std::cout << "rx:" << mrx << std::endl;
        memset(buf, 0, sizeof(buf));
        //ry
        recv(sock_cli, buf, 8,0);
        mry = HexToDouble(buf);
        // std::cout << "ry:" << mry << std::endl;
        memset(buf, 0, sizeof(buf));
        //rz
        recv(sock_cli, buf, 8,0);
        mrz = HexToDouble(buf);
        // std::cout << "rz:" << mrz << std::endl;
        memset(buf, 0, sizeof(buf));

        recv(sock_cli, buf, 1556,0);
        memset(buf, 0, sizeof(buf));

        sleep(0.01);
        
    }
    close(sock_cli);
    
    memset(sendbuf, 0, sizeof(sendbuf));
    memset(recvbuf, 0, sizeof(recvbuf));

    return 1;
}


int moveAngle(double jonit_1,double jonit_2,double jonit_3,double jonit_4,double jonit_5,double jonit_6,double t)
{
    int sock_cli = initRobot();
    char sendbuf[BUFFER_SIZE];
    char recvbuf[BUFFER_SIZE];
    double toler_dist = 0.001;
    double toler_angle = 0.017;

    std::cout << "send " << std::endl;
    std::string command;
    sprintf(sendbuf,"movej([%f,%f,%f,%f,%f,%f],a=1.5,v=3,t=%f)\n",jonit_1,jonit_2,jonit_3,jonit_4,jonit_5,jonit_6,t);
    // strcpy(sendbuf,command.c_str());
    send(sock_cli, sendbuf, strlen(sendbuf),0); ///发送
    if(strcmp(sendbuf,"exit\n")==0)
    {
        perror("erroclose()r");
        return -1;
    }
    
    sleep(0.1);
    recv(sock_cli, recvbuf, 4,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 8,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
    recv(sock_cli, recvbuf, 48,0); ///接收
    memset(recvbuf, 0, sizeof(recvbuf));
   
    unsigned char buf[8];
    //joint_1
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_1 = HexToDouble(buf);
    std::cout << "joint_1:" << my_joint_1 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_2
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_2 = HexToDouble(buf);
    std::cout << "joint_2:" << my_joint_2 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_3
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_3 = HexToDouble(buf);
    std::cout << "joint_3:" << my_joint_3 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_4
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_4 = HexToDouble(buf);
    std::cout << "joint_4:" << my_joint_4 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_5
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_5 = HexToDouble(buf);
    std::cout << "joint_5:" << my_joint_5 << std::endl;
    memset(buf, 0, sizeof(buf));
    //joint_6
    recv(sock_cli, buf, 8,0); ///接收
    double my_joint_6 = HexToDouble(buf);
    std::cout << "joint_6:" << my_joint_6 << std::endl;
    memset(buf, 0, sizeof(buf));

    recv(sock_cli, buf, 1556,0);
    memset(buf, 0, sizeof(buf));

    // close(sock_cli);
    
    while(fabs(my_joint_1 - jonit_1) > toler_angle || fabs(my_joint_2 - jonit_2) > toler_angle || fabs(my_joint_3 - jonit_3) > toler_angle
      ||  fabs(my_joint_4 - jonit_4) > toler_angle || fabs(my_joint_5 - jonit_5) > toler_angle || fabs(my_joint_6 - jonit_6) > toler_angle)
    {
        // sock_cli = initRobot();
        recv(sock_cli, recvbuf, 4,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 8,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
        recv(sock_cli, recvbuf, 48,0); ///接收
        memset(recvbuf, 0, sizeof(recvbuf));
    
        unsigned char buf[8];
        //joint_1
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_1 = HexToDouble(buf);
        std::cout << "joint_1:" << my_joint_1 << std::endl;
        memset(buf, 0, sizeof(buf));
        //joint_2
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_2 = HexToDouble(buf);
        std::cout << "joint_2:" << my_joint_2 << std::endl;
        memset(buf, 0, sizeof(buf));
        //joint_3
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_3 = HexToDouble(buf);
        std::cout << "joint_3:" << my_joint_3 << std::endl;
        memset(buf, 0, sizeof(buf));
        //joint_4
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_4 = HexToDouble(buf);
        std::cout << "joint_4:" << my_joint_4 << std::endl;
        memset(buf, 0, sizeof(buf));
        //joint_5
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_5 = HexToDouble(buf);
        std::cout << "joint_5:" << my_joint_5 << std::endl;
        memset(buf, 0, sizeof(buf));
        //joint_6
        recv(sock_cli, buf, 8,0); ///接收
        my_joint_6 = HexToDouble(buf);
        std::cout << "joint_6:" << my_joint_6 << std::endl;
        memset(buf, 0, sizeof(buf));

        recv(sock_cli, buf, 1556,0);
        memset(buf, 0, sizeof(buf));

        sleep(0.01);
        
    }

    close(sock_cli);
    
    memset(sendbuf, 0, sizeof(sendbuf));
    memset(recvbuf, 0, sizeof(recvbuf));
    return 1;
}
