/*
 * gripper.cpp
 *
 *  Created on: May 6, 2018
 *      Author: user
 */


#include <modbus/modbus.h>
#include <unistd.h>
#include <iostream> 

#define GRIPPER_SLAVE_ID 0x0009
#define GRIPPER_IN_FIR_REG 0x03E8
#define GRIPPER_OUT_FIR_REG 0x07D0
modbus_t *mb;

void setGripper(unsigned char pos,unsigned char speed,unsigned char force)
{	
	
	  mb = modbus_new_rtu("/dev/ttyUSB0",115200,'N',8,1);//open port
	  modbus_set_slave(mb,GRIPPER_SLAVE_ID);//set slave address

	  modbus_connect(mb);

	  struct timeval t;
	  t.tv_sec=0;
	  t.tv_usec=1000;//set modbus time 1000ms
	  modbus_set_response_timeout(mb,1,0);
	  unsigned char msg[12]={0};
	  msg[1] = 0x09;
	  msg[2] = pos;
	  msg[5] = speed;
	  msg[4] = force;

	  modbus_write_registers(mb,GRIPPER_IN_FIR_REG,3,(unsigned short *)msg);
	  modbus_close(mb);
	  modbus_free(mb);
}

void resetGriper(void)
{	
	  std::cout << "a" << std::endl;
	  mb = modbus_new_rtu("/dev/ttyUSB0",115200,'N',8,1);//open port
	  modbus_set_slave(mb,GRIPPER_SLAVE_ID);//set slave address

	  modbus_connect(mb);

	  struct timeval t;
	  t.tv_sec  = 0;
	  t.tv_usec = 1000;//set modbus time 1000ms
	  modbus_set_response_timeout(mb,1,0);
		  
	  unsigned char msg[12]={0};
	  modbus_read_registers(mb,GRIPPER_OUT_FIR_REG,3,(unsigned short *)msg);
  
	  msg[1]=0x00;
	  modbus_write_registers(mb,GRIPPER_IN_FIR_REG,1,(unsigned short *)msg);
      //usleep(1000);
	  msg[1]=0x09;
	  modbus_write_registers(mb,GRIPPER_IN_FIR_REG,1,(unsigned short *)msg);
	  modbus_close(mb);
	  modbus_free(mb);
}