/*
 * mindCamera.h
 *
 *  Created on: Mar 7, 2018
 *      Author: user
 */

#ifndef MINDCAMERA_H_
#define MINDCAMERA_H_


#include <CameraApi.h>
#include <stdio.h>
#include <stdlib.h>

extern   int grapImg;
extern unsigned char *frameBuf;
//init sdk, open camera
int camera_init(void);

void camera_close(void);

#endif /* MINDCAMERA_H_ */