/*
 * ur5.h
 *
 *  Created on: May 6, 2018
 *      Author: user
 */

#ifndef UR5_H_
#define UR5_H_

#define TARGET_IP "192.168.2.6"
#define TARGET_PORT  30002
#define TARGET_PORT2 30003

typedef struct{
	double q_actural;
	double q_target;
	double qd_actual;
	float I_actual;
	float V_actual;
	float T_motor;
	float T_micro;
	unsigned char Joint_mode;

} Joint_struct_def;

typedef struct {
	double x;
	double y;
	double z;
	double Rx;
	double Ry;
	double Rz;
} TCP_POS_struct_def;

typedef struct {
	double x;
	double y;
	double z;
	double Rx;
	double Ry;
	double Rz;
} pose_struct;

typedef struct {
	double angle[6];

}joint_angle_type;

int setTcpPosl(TCP_POS_struct_def &pose,float t);
int setDigitOut(int i,int b);
int setTcpPos(TCP_POS_struct_def &pose,float t);
int setTcpPos(joint_angle_type &pose,float t);
int is_ok(void);
int readRobt(TCP_POS_struct_def &tcp,joint_angle_type *joint_angle);
#endif /* UR5_H_ */