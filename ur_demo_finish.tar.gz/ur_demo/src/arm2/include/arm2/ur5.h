/*
 * ur5.h
 *
 *  Created on: May 6, 2018
 *      Author: user
 */

#ifndef UR5_H_
#define UR5_H_

//#define TARGET_IP "192.168.2.6"
//#define TARGET_PORT  30002
//#define TARGET_PORT2 30003

typedef struct{
	double q_actural;
	double q_target;
	double qd_actual;
	float I_actual;
	float V_actual;
	float T_motor;
	float T_micro;
	unsigned char Joint_mode;

} Joint_struct_def;

typedef struct {
	double x;
	double y;
	double z;
	double Rx;
	double Ry;
	double Rz;
} TCP_POS_struct_def;

typedef struct {
	double x;
	double y;
	double z;
	double Rx;
	double Ry;
	double Rz;
} pose_struct;

typedef struct {
	double angle[6];

}joint_angle_type;

int move(double x,double y,double z,double rx,double ry,double rz,double a,double v,double t);
int moveAngle(double jonit_1,double jonit_2,double jonit_3,double jonit_4,double jonit_5,double jonit_6,double t);
int readRobt(TCP_POS_struct_def &tcp,joint_angle_type *joint_angle);
int setTcpPos(TCP_POS_struct_def &pose,double t);
int setTcpMulitPos(TCP_POS_struct_def &pose,double t);
int setTcpPos(joint_angle_type &pose,double t);
int setTcpMuiltPos(TCP_POS_struct_def &pose1,TCP_POS_struct_def &pose2,double t);
int moveMulitPose(double x1,double y1,double z1,double rx1,double ry1,double rz1,
                double x2,double y2,double z2,double rx2,double ry2,double rz2,double a,double v,double t);
#endif /* UR5_H_ */
