/*
 * gripper.h
 *
 *  Created on: May 6, 2018
 *      Author: user
 */

#ifndef GRIPPER_H_
#define GRIPPER_H_

void setGripper(unsigned char pos,unsigned char speed,unsigned char force);

void resetGriper(void);

#endif /* GRIPPER_H_ */