
"use strict";

let requestArm2 = require('./requestArm2.js')

module.exports = {
  requestArm2: requestArm2,
};
